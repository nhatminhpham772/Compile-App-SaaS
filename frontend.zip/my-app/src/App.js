import "./App.css";
import customConfig from './customConfig.json';
import React, { useState } from "react";

function App() {
  
  const [val,setVal]=useState([]);
  const handleAdd=()=>{
      const abc=[...customConfig.languages,[]]
      abc.pop()
      console.log(abc.length)
      setVal(abc)
  }
 
// Biên dịch chương trình  
const compile = ()=>{
  let source = document.getElementById("source").value
  let linkContainer = document.getElementById("languages").value
  let output = document.getElementById("output")
  let input = document.getElementById("input").value
  
  fetch(linkContainer, {
	  method: "POST", 
	  headers: {
	    'Content-Type': 'application/json',
	  },
	  body: JSON.stringify({"code":source,"input":input}),
	})
	.then((response) =>{ 
		if(response.status === 200){
			//alert("success")
		}
		else{
			alert("Fail")
		}
		response.json().then((data) => {
			//console.log('Success:', data);
      output.value = data
	  })
	})
	  .catch((error) => {
	    alert("Lỗi kết nối! Không tìm thấy " + linkContainer)
	  });   

}

//vào cấu hình thêm các container
const config = ()=>{
  let configpage = document.getElementById("configPage")
  configpage.classList.add('active')
  handleAdd()
}

  return (
    <div className="App" id="App">
      <div class="header">IDE ONLINE </div>
      <div class="control-panel">
        
        
        <div class="button-container">
            <button class="btn" onClick={compile}> Run </button>
        </div>
        <div class="selectlanguage">
            Select Language:
            &nbsp; &nbsp;
            <select id="languages" class="languages" onchange="changeLanguage()">
                {customConfig.languages.map(language => (
                  <option id="option" value={language.linkContainer}>{language.name}</option>
                ))}
            </select>
        </div>  
      </div>
      <div className="body">
        <div class="source">
          <p>Source: </p>
          <textarea id="source" name="source" rows="36" cols="120"></textarea>
        </div>
        <div class = "input-output">
          <p>Input: </p>
          <textarea id="input" name="input" rows="17" cols="70"></textarea>
          <p>Output: </p>
          <textarea id="output" name="output" rows="17" cols="70"></textarea>
        </div>
      </div>
      

      

      <div className="configPage " id="configPage">
      <div class="header">CONFIGURATION </div>
      <div class="control-panel">
        <div class="button-container">
            <button class="btn" onClick={save}>Save </button>
        </div>
        <div class="button-container">
            <button class="btn" onClick={cancel}> Cancel </button>
        </div>
        <div class="contain">
          <div class = "addcompiler">
            <h3>Add new language</h3><br/>
            <div>
            <a>name:  &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp;</a>
            <input></input>
            </div><br/>
            <div>
            <a>link container:  &nbsp;</a>
            <input></input><br/><br/>
            <button class="btn" onClick={()=>handleAdd()}> Add </button><br/><br/><br/>
            
            </div>
          </div>

          <div class = "showcompiler">

                {val.map((data,i)=>{
                  return(
                    <div>
                      <div>
                        <div>
                          <a>name: </a><a>{data.name}</a><br/>
                        </div>
                        <div>
                            <a>link container: </a><a>{data.linkContainer} </a>
                        </div>
                      </div>
                      
                      <div class="button-container-d">
                          <button class="btn-d" onClick={deletecontainer}> Delete </button>
                      </div>
                    </div>
                  )
              })}

          </div>
        </div>
      </div>      
      </div>
    </div>
  );
}
























// not use


function cancel(){
  let configpage = document.getElementById("configPage")
  configpage.classList.remove('active')
}
function save(){
  let configpage = document.getElementById("configPage")
  configpage.classList.remove('active')
  let object = {
    "name":"Java",
    "linkContainer":"http://localhost:3005/run"
  }
  customConfig.languages = []
  customConfig.languages.push(object)
  
  console.log(customConfig.languages.length)
}
function refesh(){
  let languages = document.getElementById("languages")
  let option = document.getElementsByTagName('option')
  while( option.length >0){
    languages.remove(option)
  }
  customConfig.languages.map(language => {
    let added = document.createElement("option");
    added.value = language.linkContainer;
    added.innerHTML = language.name;
    languages.append(added)
  })
}

function add(){

}
function deletecontainer(){

}
export default App;
